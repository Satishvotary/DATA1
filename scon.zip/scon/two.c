#include<stdio.h>

print (char str[10])
{
	printf("%s\n",str);
}




