#include<stdio.h>

int main()
{
print("vamsi");
}
