#!/bin/bash

a=`pwd`
echo "asd:$a"
