#!/bin/bash

va_a=poky
va_b=meta-openembedded

clone_bare_minmum_repo()
{
	eval pwd
	echo "################# cloning poky and open-embedded #############"
	if [ -d $va_a ]
	then 
		echo "poky is alrady exist"
	else 
	#	mkdir poky
		git clone -b rocko git://git.yoctoproject.org/poky.git

	fi
	if [ -d $va_b ]
	then
		echo "meta-openembedded is aleady exist"
	else 
        	#mkdir meta-openembedded
		git clone -b rocko git://git.openembedded.org/meta-openembedded.git
	fi
}















echo "Board Name"
read project
wd=eval pwd
if [ -d $project ]
then
	echo "######### build name is alrady exist #########"
	cd $project/sources
	clone_bare_minmum_repo va_a va_b
else
	echo "##### created new directory ######"
	mkdir -p $project/sources
	cd $project/sources
	eval pwd
	clone_bare_minmum_repo va_a va_b
fi






