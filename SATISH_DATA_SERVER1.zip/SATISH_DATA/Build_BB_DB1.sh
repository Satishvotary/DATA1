#!/bin/bash
#sudo apt-get install gawk wget git-core diffstat unzip texinfo gcc-multilib build-essential chrpath
#echo "enter manchine name:"
printf "1:beaglebone \n2.dragonboard-410c\n\n"
echo "Enter your machine number:"

read num
if [ $num -eq 1 ]
then
	machine="beaglebone"
else [ $num -eq 2 ]
	machine="dragonboard-410c"
fi
#echo $machine
#echo "enter kernel version:"
#read kernel
#ls
#sudo su
if [ $machine == "dragonboard-410c" ]
then
        en="dragon-build"
        dir="./dragon/sources"
        mkdir -p $dir
        cd $dir
        git clone -b rocko git://git.yoctoproject.org/poky.git
        git clone -b rocko git://git.openembedded.org/meta-openembedded
        git clone -b rocko https://github.com/ndechesne/meta-qcom.git
	cd ..
	source sources/poky/oe-init-build-env $en
	echo 'MACHINE = "dragonboard-410c"' >> conf/local.conf

	#source sources/poky/oe-init-build-env $en
	cd ..
	BSDIR=`pwd`
	
	meta_dir="meta-qcom"
	bit_bake_cmd="core-image-base"
elif [ $machine == "beaglebone" ]
then
	en="bb-build"
	dir="./BB/sources"
	mkdir -p $dir
	cd $dir
        git clone -b rocko git://git.yoctoproject.org/poky.git
        git clone -b rocko git://git.openembedded.org/meta-openembedded
	git clone -b rocko https://github.com/ndechesne/meta-qcom.git
	cd ..
	source sources/poky/oe-init-build-env $en
	echo 'MACHINE = "beaglebone"' >> conf/local.conf
	cd ..
	BSDIR=`pwd`
	bit_bake_cmd="core-image-base"
fi 
if [ $machine == "beaglebone" ]
then
	echo 'PREFERRED_VERSION_linux-beaglebone = "4.9"'>>$en/conf/local.conf
else

	echo 'PREFERRED_VERSION_linux-linaro-qcom = "4.9"'>>$en/conf/local.conf
fi
echo 'DISTRO_FEATURES_remove = "x11 wayland"' >>$en/conf/local.conf
echo 'DISTRO_FEATURES_append = " systemd"' >>$en/conf/local.conf
echo 'VIRTUAL-RUNTIME_init_manager = "systemd"' >>$en/conf/local.conf
echo 'PARALLEL_MAKE ?= " -j ${@oe.utils.cpu_count()}"' >>$en/conf/local.conf
echo 'BB_NUMBER_THREADS ?= " ${@oe.utils.cpu_count()}"' >>$en/conf/local.conf

if [ $machine != "beaglebone" ]
then
	> $en/conf/bblayers.conf
	# LAYER_CONF_VERSION is increased each time build/conf/bblayers.conf
	# changes incompatibly
	echo "bblayer"
	#cd ..
	#BSDIR= pwd
	echo 'POKY_BBLAYERS_CONF_VERSION = "2"'>>$en/conf/bblayers.conf
	echo 'BBPATH = "${TOPDIR}"'>>$en/conf/bblayers.conf
	echo 'BBFILES ?= ""'>>$en/conf/bblayers.conf
	echo "$BSDIR"
	echo  "BSPDIR := \"$BSDIR\"">>$en/conf/bblayers.conf
	echo 'BBLAYERS ?= " \'>>$en/conf/bblayers.conf
	echo '  ${BSPDIR}/sources/poky/meta \'>>$en/conf/bblayers.conf
	echo '  ${BSPDIR}/sources/poky/meta-poky \'>>$en/conf/bblayers.conf
	echo '  ${BSPDIR}/sources/poky/meta-yocto-bsp \'>>$en/conf/bblayer.conf
	echo '  ${BSPDIR}/sources/meta-openembedded/meta-oe \'>>$en/conf/bblayers.conf
	echo '  ${BSPDIR}/sources/meta-openembedded/meta-multimedia \'>>$en/conf/bblayers.conf
	echo "  "\${BSPDIR}"/sources/$meta_dir \ ">>$en/conf/bblayers.conf
	echo '  "'>>$en/conf/bblayers.conf
	echo 'BBLAYERS_NON_REMOVABLE ?= " \'>>$en/conf/bblayers.conf
	echo '  ${BSPDIR}/sources/poky/meta \'>>$en/conf/bblayers.conf
	echo '  ${BSPDIR}/sources/poky/meta-poky \'>>$en/conf/bblayers.conf
	echo '  "'>>$en/conf/bblayers.conf
fi
bitbake $bit_bake_cmd
#bitbake core-image-base
